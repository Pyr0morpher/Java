import java.util.Scanner;

class Main {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	
	//Sets values for first name, last name, age, and height
    System.out.println("Enter your first name: ");
    String first = scan.nextLine();
  
    System.out.println("Enter your last name: ");
    String last = scan.nextLine();

    System.out.println("Enter your age: ");
    int age = scan.nextInt();
    
    System.out.println("Enter your height in inches: ");
    int height = scan.nextInt();
    
    //Calls a new instance of the class
    Person one = new Person(first, last, age, height);
    
    //Output
    System.out.println("Hi, my name is " + one.getFirst() + " " + one.getLast());
    System.out.println("I am " + one.getAge() + " years old and I am " + one.convertHeight(one.getHeight()) + " tall.");
  }
}