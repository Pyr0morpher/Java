class Person {

  private String firstName;
  private String lastName;
  private int age;
  private int height; //inches

  public Person() {

    firstName = "Corbin";
    lastName = "Goodman";
    age = 17;
    height = 70;
  }

  public Person(String f, String l, int a, int h) {

    firstName = f;
    lastName = l;
    age = a;
    height = h;
  }

  public void setFirst(String f) {
  
    firstName = f;
  }

  public void setLast(String l) {
  
    lastName = l;
  }

  public void setAge(int a) {
  
    age = a;
  }

  public void setHeight(int h) {
  
    height = h;
  }

  public String getFirst() {
  
    return firstName;
  }

  public String getLast() {
  
    return lastName;
  }

  public int getAge() {
  
    return age;
  }

  public int getHeight() {
  
    return height;
  }

  public String convertHeight(int h){
    String height = "";
    int feet = h / 12;
    int inches = h % 12;

    height = (feet + "' " + inches + "\"");
    return height;
  }
}