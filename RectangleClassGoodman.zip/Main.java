public class Main {

	public static void main(String[] args) {
		
		Rectangle one = new Rectangle(7, 13);

    System.out.println("Length " + one.getLength());
    System.out.println("Width " + one.getWidth());
    System.out.println("Area " + one.getArea());
    System.out.println("Perimeter " + one.getPerimeter());
	}
}